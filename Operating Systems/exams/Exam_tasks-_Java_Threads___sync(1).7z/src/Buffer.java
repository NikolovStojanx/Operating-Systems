public class Buffer {
    public void produce(){
        System.out.printf("Producer is producing....");
    }

    public void check(){
        System.out.printf("Controller is checking....");
    }
}
